### Link For The Results:
https://amityedu96491-my.sharepoint.com/:x:/g/personal/shaina_mehta_s_amity_edu/EbXiWaOrwYlBk-QJmnw3ZssBu8-mXXxRovA802_GzglkZg?e=dO2sv2
### Inferences:
By taking smaller image size that is of 64x64, we are facing the problem of underfitting of the model. 
Till now the model accuracy is between 40-50 percent which is given by two models that is Logistic Regression and Support Vector Machines.
