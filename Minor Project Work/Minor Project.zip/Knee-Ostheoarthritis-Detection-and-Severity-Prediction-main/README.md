# Knee-Ostheoarthritis-Detection-and-Severity-Prediction
This Repository is under development. It will be developed on May 2023.
## Authors:
### Anjali Gaur
### Shaina Mehta
### Rakshit Walia
## Submitted To:
### Prof. (Dr.) M. Parthasarathi
## Guided By:
### Prof. (Dr.) M. Parthasarathi, Nikhil J Dutta, Adil, Deepansha, Rahul Sawhney, Leah
## About The Project:
## Link of The Dataset
https://amityedu96491-my.sharepoint.com/personal/shaina_mehta_s_amity_edu/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fshaina%5Fmehta%5Fs%5Famity%5Fedu%2FDocuments%2FNTCC%20Minor%20Project&ga=1

